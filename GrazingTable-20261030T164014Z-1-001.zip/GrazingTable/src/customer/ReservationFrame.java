
package customer;
import javax.swing.JOptionPane;
import payment.PaymentFrame;
import main.MainFrame;
public class ReservationFrame extends javax.swing.JFrame {
 private int packageId;
    private String packageName;
    private double price;
    private String pax;
    private double downpayment;
    private boolean updatingDateControls = false;
    public ReservationFrame() {
   initComponents();
    setLocationRelativeTo(null);
    restrictPastDates();
}

// Gikan PackagesFrame, naay selected package
public ReservationFrame(
        int packageId,
        String packageName,
        double price,
        String pax,
        double downpayment) {

    initComponents();
    setLocationRelativeTo(null);
  
    this.packageId = packageId;
    this.packageName = packageName;
    this.price = price;
    this.pax = pax;
    this.downpayment = downpayment;

    lblPackage.setText(packageName);
    lblPax.setText(pax);
    
    
}


    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        CustomerName = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        CustomerName1 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        CustomerName2 = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        btnProceed = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        CustomerName5 = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        CustomerName6 = new javax.swing.JTextField();
        lblPackage = new javax.swing.JLabel();
        lblPax = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jcbMonth = new javax.swing.JComboBox<>();
        jcbDay = new javax.swing.JComboBox<>();
        jcbYear = new javax.swing.JComboBox<>();
        spnHour = new javax.swing.JSpinner();
        spnMinute = new javax.swing.JSpinner();
        jcbAMPM = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(245, 235, 221));

        jPanel2.setBackground(new java.awt.Color(74, 47, 32));

        jLabel1.setFont(new java.awt.Font("Georgia", 0, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 248, 237));
        jLabel1.setText("MAKE A RESERVATION");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(327, 327, 327))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(18, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(16, 16, 16))
        );

        jLabel2.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(74, 56, 40));
        jLabel2.setText("Customer Name:");

        jLabel3.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(74, 56, 40));
        jLabel3.setText("Contact Number:");

        jLabel4.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(74, 56, 40));
        jLabel4.setText("Email:");

        jLabel5.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(74, 56, 40));
        jLabel5.setText("Package:");

        jLabel6.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(74, 56, 40));
        jLabel6.setText("Event Date:");

        jLabel7.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(74, 56, 40));
        jLabel7.setText("Event Time:");

        btnProceed.setBackground(new java.awt.Color(201, 164, 92));
        btnProceed.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 14)); // NOI18N
        btnProceed.setForeground(new java.awt.Color(74, 47, 32));
        btnProceed.setText("PROCEED TO PAYMENT");
        btnProceed.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnProceed.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnProceedActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(74, 56, 40));
        jLabel8.setText("Occasion:");

        jLabel9.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(74, 56, 40));
        jLabel9.setText("Venue:");

        lblPackage.setFont(new java.awt.Font("Franklin Gothic Book", 0, 14)); // NOI18N

        lblPax.setFont(new java.awt.Font("Franklin Gothic Book", 0, 14)); // NOI18N

        jLabel11.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(74, 56, 40));
        jLabel11.setText("Pax:");

        jcbMonth.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 14)); // NOI18N
        jcbMonth.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" }));
        jcbMonth.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jcbMonthActionPerformed(evt);
            }
        });

        jcbDay.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 14)); // NOI18N
        jcbDay.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1 ", "2 ", "3 ", "4 ", "5", "6", "7", "8", "9 ", "10 ", "11 ", "12 ", "13 ", "14", "15 ", "16", "17", "18 ", "19", "20", "21 ", "22", "23", "24", "25 ", "26 ", "27", "28 ", "29 ", "30", "31" }));

        jcbYear.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 14)); // NOI18N
        jcbYear.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "2026", "2027", "2028", "2029", "2030" }));
        jcbYear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jcbYearActionPerformed(evt);
            }
        });

        spnHour.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 14)); // NOI18N
        spnHour.setToolTipText("");

        spnMinute.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 14)); // NOI18N

        jcbAMPM.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 14)); // NOI18N
        jcbAMPM.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "AM", "PM" }));
        jcbAMPM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jcbAMPMActionPerformed(evt);
            }
        });

        jButton1.setBackground(new java.awt.Color(0, 0, 0));
        jButton1.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 248, 237));
        jButton1.setText("BACK");
        jButton1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(268, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel5)
                                            .addComponent(jLabel9))
                                        .addGap(536, 536, 536))
                                    .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.LEADING))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel3)
                                        .addComponent(jLabel2)
                                        .addComponent(jLabel11)
                                        .addComponent(jLabel4))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(spnHour, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(spnMinute, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(jcbAMPM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(jcbMonth, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(jcbDay, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(18, 18, 18)
                                                .addComponent(jcbYear, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(CustomerName2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 314, Short.MAX_VALUE)
                                            .addComponent(CustomerName1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 314, Short.MAX_VALUE)
                                            .addComponent(lblPackage, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 314, Short.MAX_VALUE)
                                            .addComponent(CustomerName5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 314, Short.MAX_VALUE)
                                            .addComponent(CustomerName6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 314, Short.MAX_VALUE)
                                            .addComponent(lblPax, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 314, Short.MAX_VALUE)
                                            .addComponent(CustomerName, javax.swing.GroupLayout.Alignment.LEADING)))
                                    .addGap(126, 126, 126)))
                            .addGap(240, 240, 240))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel7)
                                .addComponent(jLabel6))
                            .addGap(322, 322, 322)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(btnProceed, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(428, 428, 428))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(461, 461, 461))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(21, 21, 21)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(CustomerName, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(23, 23, 23)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(CustomerName1, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addGap(25, 25, 25)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(CustomerName2, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblPackage, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5))
                        .addGap(27, 27, 27)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(jcbMonth, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jcbDay, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jcbYear, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(28, 28, 28)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel7)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(spnHour, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(spnMinute, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jcbAMPM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(31, 31, 31)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(CustomerName5, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(25, 25, 25)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(CustomerName6, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(lblPax, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel11))
                .addGap(17, 17, 17)
                .addComponent(btnProceed, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(88, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnProceedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnProceedActionPerformed
         
    String name = CustomerName.getText().trim();
    String contact = CustomerName1.getText().trim();
    String email = CustomerName2.getText().trim();
   String eventDate =
        jcbMonth.getSelectedItem().toString()
        + " "
        + jcbDay.getSelectedItem().toString()
        + ", "
        + jcbYear.getSelectedItem().toString();

        String eventTime =
        spnHour.getValue().toString()
        + ":"
        + String.format("%02d",
                Integer.parseInt(spnMinute.getValue().toString()))
        + " "
        + jcbAMPM.getSelectedItem().toString();
    String occasion = CustomerName5.getText().trim();
    String venue = CustomerName6.getText().trim();

    if (name.isEmpty()
            || contact.isEmpty()
            || email.isEmpty()
            || eventDate.isEmpty()
            || eventTime.isEmpty()
            || occasion.isEmpty()
            || venue.isEmpty()) {

        javax.swing.JOptionPane.showMessageDialog(
                this,
                "Please complete all required fields.",
                "Incomplete Information",
                javax.swing.JOptionPane.WARNING_MESSAGE
        );
        return;
    }

    // CONTACT NUMBER VALIDATION
    if (!contact.matches("09\\d{9}")) {
        javax.swing.JOptionPane.showMessageDialog(
                this,
                "Contact number must be exactly 11 digits and start with 09.",
                "Invalid Contact Number",
                javax.swing.JOptionPane.WARNING_MESSAGE
        );
        CustomerName1.requestFocus();
        return;
    }

    // EMAIL VALIDATION
    if (!email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
        javax.swing.JOptionPane.showMessageDialog(
                this,
                "Please enter a valid email address.",
                "Invalid Email",
                javax.swing.JOptionPane.WARNING_MESSAGE
        );
        CustomerName2.requestFocus();
        return;
    }

   new PaymentFrame(
    packageId,
    packageName,
    price,
    pax,
    downpayment,
    CustomerName.getText().trim(),
    CustomerName1.getText().trim(),
    CustomerName2.getText().trim(),
    eventDate,
    eventTime,
    CustomerName5.getText().trim(),
    CustomerName6.getText().trim()
).setVisible(true);

this.dispose();

    }//GEN-LAST:event_btnProceedActionPerformed

private void restrictPastDates() {
    updatingDateControls = true;

    try {
        java.time.LocalDate today = java.time.LocalDate.now();

        jcbYear.removeAllItems();

        for (int year = today.getYear(); year <= today.getYear() + 5; year++) {
            jcbYear.addItem(String.valueOf(year));
        }

        jcbMonth.removeAllItems();

        for (java.time.Month month : java.time.Month.values()) {
            jcbMonth.addItem(
                month.getDisplayName(
                    java.time.format.TextStyle.FULL,
                    java.util.Locale.ENGLISH
                )
            );
        }

        jcbYear.setSelectedItem(String.valueOf(today.getYear()));

        jcbMonth.setSelectedItem(
            today.getMonth().getDisplayName(
                java.time.format.TextStyle.FULL,
                java.util.Locale.ENGLISH
            )
        );

    } finally {
        updatingDateControls = false;
    }

    updateAvailableDays();
}

private void updateAvailableDays() {
    if (updatingDateControls
            || jcbYear.getSelectedItem() == null
            || jcbMonth.getSelectedItem() == null) {
        return;
    }

    updatingDateControls = true;

    try {
        java.time.LocalDate today = java.time.LocalDate.now();

        int year = Integer.parseInt(
            jcbYear.getSelectedItem().toString()
        );

        String monthText = jcbMonth.getSelectedItem().toString();

        int month;

        try {
            month = Integer.parseInt(monthText);
        } catch (NumberFormatException e) {
            month = java.time.Month.valueOf(
                monthText.toUpperCase(java.util.Locale.ENGLISH)
            ).getValue();
        }

        Object oldDay = jcbDay.getSelectedItem();

        int selectedDay = 1;

        if (oldDay != null) {
            try {
                selectedDay = Integer.parseInt(oldDay.toString());
            } catch (NumberFormatException ignored) {
                selectedDay = today.getDayOfMonth();
            }
        }

        int daysInMonth =
            java.time.YearMonth.of(year, month).lengthOfMonth();

        jcbDay.removeAllItems();

        for (int day = 1; day <= daysInMonth; day++) {
            java.time.LocalDate selectedDate =
                java.time.LocalDate.of(year, month, day);

            if (!selectedDate.isBefore(today)) {
                jcbDay.addItem(String.format("%02d", day));
            }
        }

        if (jcbDay.getItemCount() > 0) {
            String wantedDay = String.format(
                "%02d", Math.min(selectedDay, daysInMonth)
            );

            boolean found = false;

            for (int i = 0; i < jcbDay.getItemCount(); i++) {
                if (jcbDay.getItemAt(i).equals(wantedDay)) {
                    jcbDay.setSelectedIndex(i);
                    found = true;
                    break;
                }
            }

            if (!found) {
                jcbDay.setSelectedIndex(0);
            }
        }

    } finally {
        updatingDateControls = false;
    }
}


    private void jcbAMPMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jcbAMPMActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jcbAMPMActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
         new MainFrame().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jcbMonthActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jcbMonthActionPerformed
        if (!updatingDateControls) {
        updateAvailableDays();
    }
    }//GEN-LAST:event_jcbMonthActionPerformed

    private void jcbYearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jcbYearActionPerformed
        if (!updatingDateControls) {
        updateAvailableDays();
    }
    }//GEN-LAST:event_jcbYearActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ReservationFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ReservationFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ReservationFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ReservationFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ReservationFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField CustomerName;
    private javax.swing.JTextField CustomerName1;
    private javax.swing.JTextField CustomerName2;
    private javax.swing.JTextField CustomerName5;
    private javax.swing.JTextField CustomerName6;
    private javax.swing.JButton btnProceed;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JComboBox<String> jcbAMPM;
    private javax.swing.JComboBox<String> jcbDay;
    private javax.swing.JComboBox<String> jcbMonth;
    private javax.swing.JComboBox<String> jcbYear;
    private javax.swing.JLabel lblPackage;
    private javax.swing.JLabel lblPax;
    private javax.swing.JSpinner spnHour;
    private javax.swing.JSpinner spnMinute;
    // End of variables declaration//GEN-END:variables

}
