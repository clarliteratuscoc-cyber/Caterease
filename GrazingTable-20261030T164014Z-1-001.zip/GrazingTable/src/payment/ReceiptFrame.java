
package payment;

import javax.swing.*;
import java.awt.*;
import java.awt.print.PrinterException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ReceiptFrame extends JFrame {

    private JTextArea txtReceipt;
    private JButton btnPrint;
    private JButton btnDone;

    public ReceiptFrame(
            int reservationId,
            String customerName,
            String contact,
            String email,
            String packageName,
            String pax,
            double price,
            double downpayment,
            String paymentMethod,
            String eventDate,
            String eventTime,
            String occasion,
            String venue) {

        setTitle("Grazing Table - Reservation Receipt");
        setSize(600, 760);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        Color background = new Color(248, 242, 230);
        Color darkBrown = new Color(75, 52, 35);
        Color gold = new Color(177, 137, 78);

        JPanel mainPanel = new JPanel(new BorderLayout(15, 15));
        mainPanel.setBackground(background);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));

        JLabel lblTitle = new JLabel(
                "GRAZING TABLE", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Serif", Font.BOLD, 28));
        lblTitle.setForeground(darkBrown);

        JLabel lblSubtitle = new JLabel(
                "CATERING RESERVATION RECEIPT",
                SwingConstants.CENTER);
        lblSubtitle.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblSubtitle.setForeground(darkBrown);

        JPanel headerPanel = new JPanel(new GridLayout(2, 1, 5, 5));
        headerPanel.setBackground(background);
        headerPanel.add(lblTitle);
        headerPanel.add(lblSubtitle);

        Date now = new Date();
        String paymentDate =
                new SimpleDateFormat("yyyy-MM-dd").format(now);
        String paymentTime =
                new SimpleDateFormat("hh:mm a").format(now);

        txtReceipt = new JTextArea();
        txtReceipt.setEditable(false);
        txtReceipt.setFont(new Font("Monospaced", Font.PLAIN, 13));
        txtReceipt.setForeground(darkBrown);
        txtReceipt.setBackground(Color.WHITE);
        txtReceipt.setMargin(new Insets(15, 15, 15, 15));

        StringBuilder receipt = new StringBuilder();

        receipt.append("================================================\n");
        receipt.append("                  RESERVATION DETAILS\n");
        receipt.append("================================================\n\n");

        receipt.append(String.format(
                "%-19s: %d%n", "Reservation ID", reservationId));
        receipt.append(String.format(
                "%-19s: %s%n", "Payment Date", paymentDate));
        receipt.append(String.format(
                "%-19s: %s%n", "Payment Time", paymentTime));

        receipt.append("\n------------------------------------------------\n");
        receipt.append("                  CUSTOMER DETAILS\n");
        receipt.append("------------------------------------------------\n\n");

        receipt.append(String.format(
                "%-19s: %s%n", "Customer Name", customerName));
        receipt.append(String.format(
                "%-19s: %s%n", "Contact Number", contact));
        receipt.append(String.format(
                "%-19s: %s%n", "Email", email));

        receipt.append("\n------------------------------------------------\n");
        receipt.append("                   EVENT DETAILS\n");
        receipt.append("------------------------------------------------\n\n");

        receipt.append(String.format(
                "%-19s: %s%n", "Package", packageName));
        receipt.append(String.format(
                "%-19s: %s%n", "Pax", pax));
        receipt.append(String.format(
                "%-19s: %s%n", "Event Date", eventDate));
        receipt.append(String.format(
                "%-19s: %s%n", "Event Time", eventTime));
        receipt.append(String.format(
                "%-19s: %s%n", "Occasion", occasion));
        receipt.append(String.format(
                "%-19s: %s%n", "Venue", venue));

        receipt.append("\n------------------------------------------------\n");
        receipt.append("                   PAYMENT DETAILS\n");
        receipt.append("------------------------------------------------\n\n");

        receipt.append(String.format(
                "%-19s: ₱%,.2f%n", "Total Price", price));
        receipt.append(String.format(
                "%-19s: ₱%,.2f%n", "Downpayment", downpayment));
        receipt.append(String.format(
                "%-19s: %s%n", "Payment Method", paymentMethod));

        receipt.append(
                "Payment Status   : PENDING VERIFICATION\n\n");

        receipt.append("================================================\n");
        receipt.append("       Thank you for choosing Grazing Table!\n");
        receipt.append("================================================\n");

        txtReceipt.setText(receipt.toString());
        txtReceipt.setCaretPosition(0);

        JScrollPane scrollPane = new JScrollPane(txtReceipt);
        scrollPane.setBorder(
                BorderFactory.createLineBorder(gold, 1));

        btnPrint = new JButton("PRINT RECEIPT");
        btnDone = new JButton("DONE");

        styleButton(btnPrint, darkBrown, Color.WHITE);
        styleButton(btnDone, gold, Color.WHITE);

        btnPrint.addActionListener(e -> printReceipt());

        btnDone.addActionListener(e -> {
            new main.MainFrame().setVisible(true);
            dispose();
        });

        JPanel buttonPanel = new JPanel(
                new FlowLayout(FlowLayout.CENTER, 15, 5));
        buttonPanel.setBackground(background);
        buttonPanel.add(btnPrint);
        buttonPanel.add(btnDone);

        JPanel bottomPanel = new JPanel(new BorderLayout(10, 10));
        bottomPanel.setBackground(background);
        bottomPanel.add(buttonPanel, BorderLayout.CENTER);

        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        setContentPane(mainPanel);
    }

    private void styleButton(
            JButton button, Color background, Color foreground) {

        button.setFont(new Font("SansSerif", Font.BOLD, 12));
        button.setBackground(background);
        button.setForeground(foreground);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setOpaque(true);
        button.setPreferredSize(new Dimension(160, 40));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    private void printReceipt() {
        try {
            boolean printed = txtReceipt.print();

            if (printed) {
                JOptionPane.showMessageDialog(
                        this, "Receipt printed successfully.");
            }
        } catch (PrinterException e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Unable to print receipt:\n" + e.getMessage(),
                    "Print Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}