
package admin;
import grazingtable.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.SwingConstants;
import admin.AdminDashboard;
public class AdminPayment extends javax.swing.JFrame {

  
    private int selectedPaymentId = -1;
    private String selectedPaymentStatus = "";

    public AdminPayment() {
        initComponents();
        setLocationRelativeTo(null);

        DefaultTableModel model =
                (DefaultTableModel) tblPayment.getModel();

        model.setColumnIdentifiers(new String[]{
            "Payment ID",
            "Customer",
            "Package",
            "Payment Method",
            "Downpayment",
            "Payment Date",
            "Payment Time",
            "Payment Status"
        });

        DefaultTableCellRenderer leftRenderer =
                new DefaultTableCellRenderer();

        leftRenderer.setHorizontalAlignment(SwingConstants.LEFT);

        for (int i = 0; i < tblPayment.getColumnCount(); i++) {
            tblPayment.getColumnModel()
                    .getColumn(i)
                    .setCellRenderer(leftRenderer);
        }

        loadPayments();
    }

    private void loadPayments() {
        DefaultTableModel model =
                (DefaultTableModel) tblPayment.getModel();

        model.setRowCount(0);

        String sql =
                "SELECT p.payment_id, c.customer_name, "
                + "pkg.package_name, p.payment_method, "
                + "p.downpayment, p.payment_date, "
                + "p.payment_time, p.payment_status "
                + "FROM payments p "
                + "JOIN reservations r "
                + "ON p.reservation_id = r.reservation_id "
                + "JOIN customers c "
                + "ON r.customer_id = c.customer_id "
                + "JOIN packages pkg "
                + "ON r.package_id = pkg.package_id "
                + "ORDER BY p.payment_id DESC";

        try (Connection conn = DBConnection.getConnection()) {

            if (conn == null) {
                JOptionPane.showMessageDialog(
                        this,
                        "Database connection failed."
                );
                return;
            }

            try (PreparedStatement pst =
                         conn.prepareStatement(sql);
                 ResultSet rs = pst.executeQuery()) {

                while (rs.next()) {
                    model.addRow(new Object[]{
                        rs.getInt("payment_id"),
                        rs.getString("customer_name"),
                        rs.getString("package_name"),
                        rs.getString("payment_method"),
                        rs.getBigDecimal("downpayment"),
                        rs.getDate("payment_date"),
                        rs.getTime("payment_time"),
                        rs.getString("payment_status")
                    });
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Failed to load payments:\n" + e.getMessage()
            );
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblPayment = new javax.swing.JTable();
        btnVerifyPayment = new javax.swing.JButton();
        btnArchive = new javax.swing.JButton();
        btnBack = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(245, 235, 221));

        jPanel2.setBackground(new java.awt.Color(74, 47, 32));

        jLabel1.setFont(new java.awt.Font("Georgia", 0, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 248, 237));
        jLabel1.setText("ADMIN PAYMENT RECORDS");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(123, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(80, 80, 80))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(39, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(24, 24, 24))
        );

        tblPayment.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Customer", "Package", "Method", "Amount", "Date", "Time", "Status"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Integer.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblPayment.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblPaymentMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblPayment);

        btnVerifyPayment.setBackground(new java.awt.Color(74, 47, 32));
        btnVerifyPayment.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 14)); // NOI18N
        btnVerifyPayment.setForeground(new java.awt.Color(255, 248, 237));
        btnVerifyPayment.setText("VERIFY PAYMENT");
        btnVerifyPayment.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnVerifyPayment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVerifyPaymentActionPerformed(evt);
            }
        });

        btnArchive.setBackground(new java.awt.Color(201, 164, 92));
        btnArchive.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 14)); // NOI18N
        btnArchive.setForeground(new java.awt.Color(74, 47, 32));
        btnArchive.setText("ARCHIVE");
        btnArchive.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnArchive.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnArchiveActionPerformed(evt);
            }
        });

        btnBack.setBackground(new java.awt.Color(0, 0, 0));
        btnBack.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 14)); // NOI18N
        btnBack.setForeground(new java.awt.Color(255, 248, 237));
        btnBack.setText("BACK");
        btnBack.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnVerifyPayment)
                .addGap(18, 18, 18)
                .addComponent(btnArchive, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnBack, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnArchive)
                    .addComponent(btnVerifyPayment)
                    .addComponent(btnBack))
                .addGap(0, 241, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tblPaymentMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblPaymentMouseClicked
         int row = tblPayment.getSelectedRow();

        if (row == -1) {
            return;
        }

        selectedPaymentId = Integer.parseInt(
                tblPayment.getValueAt(row, 0).toString()
        );

        selectedPaymentStatus =
                tblPayment.getValueAt(row, 7).toString();
    
    }//GEN-LAST:event_tblPaymentMouseClicked

    private void btnVerifyPaymentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVerifyPaymentActionPerformed
               if (selectedPaymentId == -1) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please select a payment first."
            );
            return;
        }

        if (!"Pending".equalsIgnoreCase(
                selectedPaymentStatus)) {

            JOptionPane.showMessageDialog(
                    this,
                    "This payment is not pending."
            );
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Have you confirmed that the payment was received?",
                "Verify Payment",
                JOptionPane.YES_NO_OPTION
        );

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        String sql =
                "UPDATE payments "
                + "SET payment_status = 'Paid' "
                + "WHERE payment_id = ? "
                + "AND payment_status = 'Pending'";

        try (Connection conn = DBConnection.getConnection()) {

            if (conn == null) {
                JOptionPane.showMessageDialog(
                        this,
                        "Database connection failed."
                );
                return;
            }

            try (PreparedStatement pst =
                         conn.prepareStatement(sql)) {

                pst.setInt(1, selectedPaymentId);

                int updated = pst.executeUpdate();

                if (updated > 0) {
                    JOptionPane.showMessageDialog(
                            this,
                            "Payment verified successfully."
                    );
                } else {
                    JOptionPane.showMessageDialog(
                            this,
                            "Payment was already updated."
                    );
                }
            }

            selectedPaymentId = -1;
            selectedPaymentStatus = "";

            loadPayments();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Failed to verify payment:\n" + e.getMessage()
            );
        }

    }//GEN-LAST:event_btnVerifyPaymentActionPerformed

    private void btnArchiveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnArchiveActionPerformed
        if (selectedPaymentId == -1) {
        JOptionPane.showMessageDialog(
                this,
                "Please select a payment record first."
        );
        return;
    }

    int confirm = JOptionPane.showConfirmDialog(
            this,
            "Archive this payment record?",
            "Confirm Archive",
            JOptionPane.YES_NO_OPTION
    );

    if (confirm != JOptionPane.YES_OPTION) {
        return;
    }

    DefaultTableModel model =
            (DefaultTableModel) tblPayment.getModel();

    int row = tblPayment.getSelectedRow();

    if (row != -1) {
        model.removeRow(row);
    }

    selectedPaymentId = -1;
    selectedPaymentStatus = "";

    JOptionPane.showMessageDialog(
            this,
            "Payment record archived from the active view."
    );
    }//GEN-LAST:event_btnArchiveActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        new AdminDashboard().setVisible(true);
        dispose();
    }//GEN-LAST:event_btnBackActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AdminPayment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AdminPayment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AdminPayment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AdminPayment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdminPayment().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnArchive;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnVerifyPayment;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblPayment;
    // End of variables declaration//GEN-END:variables
}
